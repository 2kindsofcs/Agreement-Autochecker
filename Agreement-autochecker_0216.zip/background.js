chrome.webNavigation.onCommitted.addListener(function() {
    chrome.tabs.executeScript({
        file:'contentScripts.js'
    })
}, {url: [{urlMatches : 'https://*/*'}]});

// chrome.webNavigation.onCommitted.addListener(function() {
//     chrome.tabs.executeScript({
//         file: 'contentScripts.js'
//     });
// })


    // "background": {
    //     "scripts": ["background.js"],
    //     "persistent": false
    // },

// document.addEventListener('DOMContentLoaded', function () {
//     chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//         let current = tabs[0];
//         url = current.url;
//         if (!url.includes("chrome://")) {
//             chrome.webNavigation.onCommitted.addListener(function() {
//                 chrome.tabs.executeScript({
//                     file: 'contentScripts.js'
//                 })
//             })
//         }
//     })
// })


